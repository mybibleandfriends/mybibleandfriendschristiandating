# Getting Started

To run the iOS app successfully and setup your app, please follow the documentation here:

[Running on iOS](https://instamobile.io/docs/getting-started-with-react-native/running-on-ios/)

Follow the guide to install dependencies (CocoaPods) and build the project in Xcode.
